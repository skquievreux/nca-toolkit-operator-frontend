# No-Code Architects Toolkit on Cloudflare

This repository contains the configuration files needed to deploy the No-Code Architects Toolkit on Cloudflare using Cloudflare Workers and Containers.

## Project Structure

- `worker.js`: Cloudflare Worker script that handles requests and routes to the container
- `wrangler.toml`: Configuration for Cloudflare Workers and Containers
- `Dockerfile`: Container definition optimized for Cloudflare
- `SETUP_CLOUDFLARE.md`: Detailed setup instructions

## Quick Start

1. Clone the repository:
```bash
git clone https://github.com/stephengpope/no-code-architects-toolkit.git
cd no-code-architects-toolkit
```

2. Copy the Cloudflare configuration files:
```bash
cp /path/to/worker.js .
cp /path/to/wrangler.toml .
cp /path/to/SETUP_CLOUDFLARE.md .
```

3. Create local environment variables in `.dev.vars`:
```
API_KEY=your_api_key_here
S3_ENDPOINT_URL=https://your-r2-endpoint.com
S3_ACCESS_KEY=your_access_key
S3_SECRET_KEY=your_secret_key
S3_BUCKET_NAME=your_bucket_name
S3_REGION=auto
```

4. Deploy to Cloudflare:
```bash
wrangler deploy
```

For detailed setup instructions, please see [SETUP_CLOUDFLARE.md](./SETUP_CLOUDFLARE.md).

## Benefits of Cloudflare Deployment

- **Global Distribution**: Your API is accessible from Cloudflare's global network of data centers
- **Auto-scaling**: Containers scale automatically based on demand
- **Cost-effective**: Only pay for the compute resources you use
- **Low Latency**: Requests are processed in the closest data center to the user
- **Security**: Built-in DDoS protection and security features from Cloudflare

## Storage Options

The No-Code Architects Toolkit requires storage for processing media files. With Cloudflare deployment, you have several options:

1. **Cloudflare R2**: The recommended option for best performance with Cloudflare
2. **AWS S3**: Compatible with standard S3 API
3. **Google Cloud Storage**: Using GCP service account

## Limitations

- Container cold starts may cause initial requests to be slower
- Long-running processes (>5 minutes) should use webhooks for notifications
- Maximum file size is subject to Cloudflare's limits

## Support

For support with the No-Code Architects Toolkit, join the [No-Code Architects Community](https://www.skool.com/no-code-architects).

For Cloudflare-specific deployment issues, refer to the [Cloudflare Containers documentation](https://developers.cloudflare.com/containers/).
