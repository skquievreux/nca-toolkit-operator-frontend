
import { Container } from "cloudflare:workers";

// Define the container class for the No-Code Architects Toolkit
export class ToolkitContainer extends Container {
  defaultPort = 8080; // The toolkit exposes port 8080 by default
}

// Main worker entry point
export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    
    // Simple router to forward requests to the container
    if (url.pathname.startsWith('/v1/')) {
      // Forward API requests to the container
      return env.TOOLKIT.fetch(request);
    } else {
      // Return a simple landing page for other requests
      return new Response(`
        <html>
          <head>
            <title>No-Code Architects Toolkit API</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
              h1 { color: #333; }
            </style>
          </head>
          <body>
            <h1>No-Code Architects Toolkit API</h1>
            <p>This is the No-Code Architects Toolkit API. Make API requests to /v1/ endpoints.</p>
            <p>For documentation, see <a href="https://github.com/stephengpope/no-code-architects-toolkit">GitHub Repository</a></p>
          </body>
        </html>
      `, {
        headers: {
          'content-type': 'text/html;charset=UTF-8',
        },
      });
    }
  }
};
