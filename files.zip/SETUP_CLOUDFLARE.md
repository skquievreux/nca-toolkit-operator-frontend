# Deploying No-Code Architects Toolkit on Cloudflare

This guide walks you through deploying the No-Code Architects Toolkit on Cloudflare using Cloudflare Workers and Containers.

## Prerequisites

- A Cloudflare account with Workers and Containers enabled
- Wrangler CLI installed: `npm install -g wrangler`
- Authentication with wrangler: `wrangler login`
- Docker installed and running (required for Wrangler to build and push container images)
- Access to storage (S3-compatible or GCP)

## Setup Process

### 1. Prepare Environment Variables

Create a `.dev.vars` file to store your local development environment variables:

```sh
API_KEY=your_api_key_here

# For S3-compatible storage (including Cloudflare R2)
S3_ENDPOINT_URL=https://your-endpoint-url
S3_ACCESS_KEY=your_access_key
S3_SECRET_KEY=your_secret_key
S3_BUCKET_NAME=your_bucket_name
S3_REGION=auto  # Use "auto" for Cloudflare R2 or specify a region

# For GCP Storage (alternative)
# GCP_SA_CREDENTIALS='{"your":"service_account_json"}'
# GCP_BUCKET_NAME=your_gcs_bucket_name
```

### 2. Set Environment Variables in Cloudflare

You'll need to add these environment variables to your Cloudflare account so they can be accessed during deployment:

```sh
wrangler secret put API_KEY
# Input your API key when prompted

# For S3/R2 storage
wrangler secret put S3_ENDPOINT_URL
wrangler secret put S3_ACCESS_KEY
wrangler secret put S3_SECRET_KEY
wrangler secret put S3_BUCKET_NAME
wrangler secret put S3_REGION

# For GCP storage
# wrangler secret put GCP_SA_CREDENTIALS
# wrangler secret put GCP_BUCKET_NAME
```

### 3. Configure Storage

#### Using Cloudflare R2 (Recommended)

1. Create an R2 bucket in your Cloudflare account
2. Get your R2 credentials from Cloudflare dashboard
3. Configure the `.dev.vars` and secrets with:
   - S3_ENDPOINT_URL: `https://<your-account-id>.r2.cloudflarestorage.com`
   - S3_REGION: `auto`
   - S3_ACCESS_KEY: Your R2 access key
   - S3_SECRET_KEY: Your R2 secret key
   - S3_BUCKET_NAME: Your R2 bucket name

### 4. Deploy to Cloudflare

Deploy the worker and container:

```sh
wrangler deploy
```

The first deployment will take several minutes as Cloudflare builds and pushes the Docker container image.

### 5. Verify Deployment

After deployment completes, your API will be accessible at:
`https://no-code-architects-toolkit.<your-worker-subdomain>.workers.dev/`

Test the API with:

```sh
curl -X POST https://no-code-architects-toolkit.<your-worker-subdomain>.workers.dev/v1/toolkit/test \
  -H "X-API-Key: your_api_key_here"
```

## Configuration Options

### Container Resources

You can adjust CPU, memory and other settings in the `wrangler.toml` file:

```toml
[container]
image = "ghcr.io/stephengpope/no-code-architects-toolkit:latest"
container_name = "TOOLKIT"
cpu = 4        # Increase for better performance
memory_mb = 8192  # Increase for handling larger files

[container.autoscaling]
minimum_instances = 1  # Minimum number of containers running
cpu_target = 75        # When to scale up (CPU percentage)
```

### Custom Domain

To use a custom domain:

1. Add a custom domain in Cloudflare Workers dashboard
2. Create a CNAME record pointing to your worker

## Troubleshooting

- **Deployment Timeouts**: Container builds may take time. If it fails, try again.
- **Container Startup Issues**: Check logs in Cloudflare dashboard.
- **Storage Connection Problems**: Verify your storage credentials are correct.
- **Memory/CPU Limitations**: Increase container resources in wrangler.toml.

## Important Notes

- Long-running processes should use the `webhook_url` parameter to avoid timeouts.
- Container instances start up on demand and may have cold starts on first request.
- For operations exceeding 5 minutes, ensure proper handling with webhooks.
