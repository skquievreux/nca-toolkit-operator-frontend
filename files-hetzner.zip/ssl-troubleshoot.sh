#!/bin/bash

# SSL-Fehlerbehebungsskript für das No-Code Architects Toolkit
# Dieses Skript hilft bei der Diagnose und Behebung von SSL-Problemen

set -e

# Farbcodes für bessere Lesbarkeit
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Banner anzeigen
echo -e "${GREEN}"
echo "====================================================="
echo "  No-Code Architects Toolkit - SSL-Fehlerbehebung"
echo "====================================================="
echo -e "${NC}"

# Überprüfen, ob das Skript als Root ausgeführt wird
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Bitte führen Sie das Skript als Root aus.${NC}"
  exit 1
fi

# Überprüfen, ob docker compose installiert ist
if ! command -v docker &> /dev/null; then
  echo -e "${RED}Docker ist nicht installiert.${NC}"
  exit 1
fi

# Überprüfen, ob das Toolkit-Verzeichnis existiert
if [ ! -d "/opt/nca-toolkit" ]; then
  echo -e "${RED}Das Toolkit-Verzeichnis /opt/nca-toolkit existiert nicht.${NC}"
  read -p "Möchten Sie fortfahren und ein neues Verzeichnis erstellen? (j/n): " CREATE_DIR
  if [ "$CREATE_DIR" == "j" ] || [ "$CREATE_DIR" == "J" ]; then
    mkdir -p /opt/nca-toolkit
    cd /opt/nca-toolkit
  else
    echo -e "${RED}Abbruch.${NC}"
    exit 1
  fi
else
  cd /opt/nca-toolkit
fi

# Domain-Name erfragen
read -p "Geben Sie Ihren Domain-Namen ein: " DOMAIN_NAME
read -p "Geben Sie Ihre E-Mail-Adresse für Let's Encrypt ein: " EMAIL_ADDRESS

# Menü anzeigen
while true; do
  echo -e "\n${GREEN}SSL-Fehlerbehebungsoptionen:${NC}"
  echo "1. Diagnose durchführen"
  echo "2. SSL-Zertifikat neu erstellen"
  echo "3. Nginx-Konfiguration neu erstellen"
  echo "4. Ports überprüfen"
  echo "5. DNS-Einträge überprüfen"
  echo "6. Container-Logs anzeigen"
  echo "7. Beenden"
  
  read -p "Wählen Sie eine Option (1-7): " OPTION
  
  case $OPTION in
    1)
      echo -e "\n${GREEN}Diagnose wird durchgeführt...${NC}"
      
      # DNS-Prüfung
      echo -e "\n${YELLOW}DNS-Prüfung:${NC}"
      IP_ADDR=$(dig +short $DOMAIN_NAME)
      SERVER_IP=$(curl -s ifconfig.me)
      
      if [ "$IP_ADDR" == "$SERVER_IP" ]; then
        echo -e "${GREEN}✓ DNS-Eintrag ist korrekt konfiguriert.${NC}"
      else
        echo -e "${RED}✗ DNS-Eintrag zeigt nicht auf diesen Server.${NC}"
        echo "  Domain IP: $IP_ADDR"
        echo "  Server IP: $SERVER_IP"
      fi
      
      # Port-Prüfung
      echo -e "\n${YELLOW}Port-Prüfung:${NC}"
      HTTP_OPEN=$(nc -z -w1 localhost 80 && echo "open" || echo "closed")
      HTTPS_OPEN=$(nc -z -w1 localhost 443 && echo "open" || echo "closed")
      
      if [ "$HTTP_OPEN" == "open" ]; then
        echo -e "${GREEN}✓ Port 80 (HTTP) ist offen.${NC}"
      else
        echo -e "${RED}✗ Port 80 (HTTP) ist geschlossen.${NC}"
      fi
      
      if [ "$HTTPS_OPEN" == "open" ]; then
        echo -e "${GREEN}✓ Port 443 (HTTPS) ist offen.${NC}"
      else
        echo -e "${RED}✗ Port 443 (HTTPS) ist geschlossen.${NC}"
      fi
      
      # Container-Prüfung
      echo -e "\n${YELLOW}Container-Prüfung:${NC}"
      NGINX_RUNNING=$(docker ps | grep nginx-proxy > /dev/null && echo "running" || echo "stopped")
      CERTBOT_RUNNING=$(docker ps | grep certbot > /dev/null && echo "running" || echo "stopped")
      TOOLKIT_RUNNING=$(docker ps | grep nca-toolkit > /dev/null && echo "running" || echo "stopped")
      
      if [ "$NGINX_RUNNING" == "running" ]; then
        echo -e "${GREEN}✓ Nginx-Container läuft.${NC}"
      else
        echo -e "${RED}✗ Nginx-Container ist gestoppt.${NC}"
      fi
      
      if [ "$CERTBOT_RUNNING" == "running" ]; then
        echo -e "${GREEN}✓ Certbot-Container läuft.${NC}"
      else
        echo -e "${RED}✗ Certbot-Container ist gestoppt.${NC}"
      fi
      
      if [ "$TOOLKIT_RUNNING" == "running" ]; then
        echo -e "${GREEN}✓ Toolkit-Container läuft.${NC}"
      else
        echo -e "${RED}✗ Toolkit-Container ist gestoppt.${NC}"
      fi
      
      # SSL-Zertifikat-Prüfung
      echo -e "\n${YELLOW}SSL-Zertifikat-Prüfung:${NC}"
      if [ -d "certbot/conf/live/$DOMAIN_NAME" ]; then
        CERT_EXPIRY=$(docker compose exec -T nginx openssl x509 -dates -noout -in /etc/letsencrypt/live/$DOMAIN_NAME/cert.pem | grep notAfter)
        echo -e "${GREEN}✓ SSL-Zertifikat gefunden.${NC}"
        echo "  $CERT_EXPIRY"
      else
        echo -e "${RED}✗ Kein SSL-Zertifikat für $DOMAIN_NAME gefunden.${NC}"
      fi
      
      # Nginx-Konfigurationsprüfung
      echo -e "\n${YELLOW}Nginx-Konfigurationsprüfung:${NC}"
      if [ -f "nginx/app.conf" ]; then
        CONFIG_TEST=$(docker compose exec -T nginx nginx -t 2>&1)
        if echo "$CONFIG_TEST" | grep -q "test is successful"; then
          echo -e "${GREEN}✓ Nginx-Konfiguration ist gültig.${NC}"
        else
          echo -e "${RED}✗ Nginx-Konfiguration ist fehlerhaft.${NC}"
          echo "$CONFIG_TEST"
        fi
      else
        echo -e "${RED}✗ Nginx-Konfigurationsdatei nicht gefunden.${NC}"
      fi
      
      echo -e "\n${GREEN}Diagnose abgeschlossen.${NC}"
      ;;
      
    2)
      echo -e "\n${GREEN}SSL-Zertifikat wird neu erstellt...${NC}"
      
      # Zuerst die alten Zertifikatsdateien sichern, falls sie existieren
      if [ -d "certbot/conf/live/$DOMAIN_NAME" ]; then
        echo -e "${YELLOW}Vorhandene Zertifikate werden gesichert...${NC}"
        mkdir -p certbot/backup
        cp -r certbot/conf/live certbot/backup/
      fi
      
      echo -e "${YELLOW}Container werden gestoppt...${NC}"
      docker compose down
      
      echo -e "${YELLOW}Nur Nginx-Container wird gestartet...${NC}"
      docker compose up -d nginx
      
      echo -e "${YELLOW}SSL-Zertifikat wird beantragt...${NC}"
      docker compose run --rm certbot certonly --force-renewal --webroot --webroot-path=/var/www/certbot --email ${EMAIL_ADDRESS} --agree-tos --no-eff-email -d ${DOMAIN_NAME} -d www.${DOMAIN_NAME}
      
      echo -e "${YELLOW}Alle Container werden gestartet...${NC}"
      docker compose down
      docker compose up -d
      
      echo -e "${GREEN}SSL-Zertifikat wurde neu erstellt.${NC}"
      ;;
      
    3)
      echo -e "\n${GREEN}Nginx-Konfiguration wird neu erstellt...${NC}"
      
      # Sicherungskopie der vorhandenen Konfiguration erstellen
      if [ -f "nginx/app.conf" ]; then
        cp nginx/app.conf nginx/app.conf.bak
        echo -e "${YELLOW}Sicherungskopie der vorhandenen Konfiguration wurde erstellt: nginx/app.conf.bak${NC}"
      fi
      
      # Neue Nginx-Konfiguration erstellen
      cat > nginx/app.conf << EOL
server {
    listen 80;
    server_name ${DOMAIN_NAME} www.${DOMAIN_NAME};
    
    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }
    
    location / {
        return 301 https://\$host\$request_uri;
    }
}

server {
    listen 443 ssl;
    server_name ${DOMAIN_NAME} www.${DOMAIN_NAME};
    
    ssl_certificate /etc/letsencrypt/live/${DOMAIN_NAME}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${DOMAIN_NAME}/privkey.pem;
    
    include /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;
    
    location / {
        proxy_pass http://nca-toolkit:8080;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }

    # Größere Uploads erlauben
    client_max_body_size 500M;
}
EOL
      
      echo -e "${YELLOW}Container werden neu gestartet...${NC}"
      docker compose restart nginx
      
      echo -e "${GREEN}Nginx-Konfiguration wurde neu erstellt und Container wurde neu gestartet.${NC}"
      ;;
      
    4)
      echo -e "\n${GREEN}Ports werden überprüft...${NC}"
      
      echo -e "${YELLOW}Lokale Ports:${NC}"
      netstat -tuln | grep -E ':(80|443)'
      
      echo -e "\n${YELLOW}Firewall-Status:${NC}"
      ufw status | grep -E '(80|443)'
      
      echo -e "\n${YELLOW}Port-Test:${NC}"
      curl -sI http://${DOMAIN_NAME} | head -n 1
      curl -sI https://${DOMAIN_NAME} | head -n 1
      
      read -p "Möchten Sie die Firewall für HTTP und HTTPS aktualisieren? (j/n): " UPDATE_FIREWALL
      if [ "$UPDATE_FIREWALL" == "j" ] || [ "$UPDATE_FIREWALL" == "J" ]; then
        ufw allow http
        ufw allow https
        echo -e "${GREEN}Firewall für HTTP und HTTPS aktualisiert.${NC}"
      fi
      ;;
      
    5)
      echo -e "\n${GREEN}DNS-Einträge werden überprüft...${NC}"
      
      SERVER_IP=$(curl -s ifconfig.me)
      echo -e "Server-IP: ${YELLOW}${SERVER_IP}${NC}"
      
      echo -e "\n${YELLOW}DNS-Einträge für ${DOMAIN_NAME}:${NC}"
      dig +short ${DOMAIN_NAME} A
      dig +short www.${DOMAIN_NAME} A
      
      echo -e "\n${YELLOW}DNS-Propagierung:${NC}"
      echo "https://dnschecker.org/#A/${DOMAIN_NAME}"
      
      echo -e "\nStellen Sie sicher, dass die folgenden DNS-Einträge gesetzt sind:"
      echo -e "A-Record: ${DOMAIN_NAME} → ${SERVER_IP}"
      echo -e "A-Record: www.${DOMAIN_NAME} → ${SERVER_IP}"
      ;;
      
    6)
      echo -e "\n${GREEN}Container-Logs werden angezeigt...${NC}"
      
      echo -e "\n${YELLOW}Welchen Container-Log möchten Sie sehen?${NC}"
      echo "1. Nginx"
      echo "2. Certbot"
      echo "3. NCA Toolkit"
      echo "4. Alle"
      
      read -p "Wählen Sie eine Option (1-4): " LOG_OPTION
      
      case $LOG_OPTION in
        1)
          docker compose logs -f nginx
          ;;
        2)
          docker compose logs -f certbot
          ;;
        3)
          docker compose logs -f nca-toolkit
          ;;
        4)
          docker compose logs -f
          ;;
        *)
          echo -e "${RED}Ungültige Option.${NC}"
          ;;
      esac
      ;;
      
    7)
      echo -e "\n${GREEN}Das Skript wird beendet.${NC}"
      exit 0
      ;;
      
    *)
      echo -e "${RED}Ungültige Option. Bitte wählen Sie eine Option von 1 bis 7.${NC}"
      ;;
  esac
done
