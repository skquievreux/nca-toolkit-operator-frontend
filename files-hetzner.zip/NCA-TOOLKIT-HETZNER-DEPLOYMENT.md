# No-Code Architects Toolkit auf Hetzner - Deployment-Anleitung

Diese Dokumentation führt Sie durch die Bereitstellung des No-Code Architects Toolkit auf einem Hetzner Server. Die Anleitung umfasst die Serverauswahl, Installation, Konfiguration und SSL-Zertifikat-Einrichtung.

## Inhaltsverzeichnis

1. [Serverauswahl](#1-serverauswahl)
2. [Server-Einrichtung](#2-server-einrichtung)
3. [Docker und Docker Compose installieren](#3-docker-und-docker-compose-installieren)
4. [No-Code Architects Toolkit bereitstellen](#4-no-code-architects-toolkit-bereitstellen)
5. [SSL-Zertifikat einrichten](#5-ssl-zertifikat-einrichten)
6. [Toolkit testen](#6-toolkit-testen)
7. [Fehlerbehandlung](#7-fehlerbehandlung)
8. [Wartung und Updates](#8-wartung-und-updates)

## 1. Serverauswahl

Für das No-Code Architects Toolkit wird empfohlen, mindestens einen CX22 Server zu wählen:

- **Empfohlene Konfiguration**: CX22 oder höher
  - 2 vCPUs
  - 4 GB RAM
  - 40 GB Speicher
  - Inkl. 20 TB Traffic (EU)

Für produktive Umgebungen mit höherer Last empfehlen wir den CX32:
- 4 vCPUs
- 8 GB RAM
- 80 GB Speicher

**Betriebssystem**: Ubuntu 22.04 LTS

## 2. Server-Einrichtung

### 2.1 Server bestellen und einrichten

1. Melden Sie sich bei Ihrem Hetzner-Account an
2. Wählen Sie "Cloud" → "Server" → "Server erstellen"
3. Wählen Sie die oben empfohlene Konfiguration
4. Wählen Sie die Region (z.B. Nürnberg oder Falkenstein)
5. Wählen Sie Ubuntu 22.04 als Betriebssystem
6. Erstellen Sie einen SSH-Schlüssel oder wählen Sie einen vorhandenen
7. Geben Sie einen Servernamen ein (z.B. "nca-toolkit")
8. Klicken Sie auf "Server erstellen"

### 2.2 Verbindung zum Server herstellen

```bash
ssh root@<Ihre-Server-IP>
```

### 2.3 System aktualisieren

```bash
apt update && apt upgrade -y
```

### 2.4 Firewall einrichten

```bash
apt install -y ufw
ufw allow ssh
ufw allow http
ufw allow https
ufw enable
```

## 3. Docker und Docker Compose installieren

### 3.1 Docker installieren

```bash
apt install -y apt-transport-https ca-certificates curl software-properties-common
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
echo "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
apt update
apt install -y docker-ce docker-ce-cli containerd.io
systemctl enable docker
systemctl start docker
```

### 3.2 Docker Compose installieren

```bash
apt install -y docker-compose-plugin
```

## 4. No-Code Architects Toolkit bereitstellen

### 4.1 Projektverzeichnis erstellen

```bash
mkdir -p /opt/nca-toolkit
cd /opt/nca-toolkit
```

### 4.2 Repository klonen

```bash
apt install -y git
git clone https://github.com/stephengpope/no-code-architects-toolkit.git .
```

### 4.3 Umgebungsvariablen konfigurieren

Erstellen Sie eine `.env`-Datei:

```bash
nano .env
```

Fügen Sie folgende Konfiguration ein:

```
# API-Konfiguration
API_KEY=IhrSichererAPISchlüssel

# Speicherkonfiguration
LOCAL_STORAGE_PATH=/data

# Performance-Einstellungen
MAX_QUEUE_LENGTH=10
GUNICORN_WORKERS=4
GUNICORN_TIMEOUT=300

# Optional: S3-kompatible Speicherkonfiguration
# S3_ENDPOINT_URL=https://your-s3-endpoint
# S3_ACCESS_KEY=your-access-key
# S3_SECRET_KEY=your-secret-key
# S3_BUCKET_NAME=your-bucket-name
# S3_REGION=auto
```

### 4.4 Docker Compose Konfiguration erstellen

Erstellen Sie eine `docker-compose.yml`-Datei:

```bash
nano docker-compose.yml
```

Fügen Sie folgende Konfiguration ein:

```yaml
version: '3'

services:
  nca-toolkit:
    image: stephengpope/no-code-architects-toolkit:latest
    container_name: nca-toolkit
    ports:
      - "80:8080"
    volumes:
      - ./data:/data
    env_file:
      - .env
    restart: unless-stopped

  nginx:
    image: nginx:latest
    container_name: nginx-proxy
    ports:
      - "443:443"
    volumes:
      - ./nginx:/etc/nginx/conf.d
      - ./certbot/conf:/etc/letsencrypt
      - ./certbot/www:/var/www/certbot
    depends_on:
      - nca-toolkit
    restart: unless-stopped

  certbot:
    image: certbot/certbot:latest
    container_name: certbot
    volumes:
      - ./certbot/conf:/etc/letsencrypt
      - ./certbot/www:/var/www/certbot
    entrypoint: "/bin/sh -c 'trap exit TERM; while :; do certbot renew; sleep 12h & wait $${!}; done;'"
```

### 4.5 Verzeichnisse für Daten und Zertifikate erstellen

```bash
mkdir -p data nginx certbot/conf certbot/www
```

## 5. SSL-Zertifikat einrichten

### 5.1 Nginx-Konfiguration erstellen

```bash
nano nginx/app.conf
```

Fügen Sie folgende Konfiguration ein (ersetzen Sie `your-domain.com` durch Ihre Domain):

```nginx
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    
    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }
    
    location / {
        return 301 https://$host$request_uri;
    }
}

server {
    listen 443 ssl;
    server_name your-domain.com www.your-domain.com;
    
    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;
    
    include /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;
    
    location / {
        proxy_pass http://nca-toolkit:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### 5.2 SSL-Zertifikat beantragen

Starten Sie vorübergehend nur den Nginx-Container:

```bash
docker-compose up -d nginx
```

Führen Sie das Certbot-Skript aus, um ein SSL-Zertifikat zu erhalten:

```bash
docker-compose run --rm certbot certonly --webroot --webroot-path=/var/www/certbot --email your-email@example.com --agree-tos --no-eff-email -d your-domain.com -d www.your-domain.com
```

### 5.3 SSL-Optionen und DH-Parameter erstellen

```bash
mkdir -p certbot/conf
curl -s https://raw.githubusercontent.com/certbot/certbot/master/certbot-nginx/certbot_nginx/_internal/tls_configs/options-ssl-nginx.conf > certbot/conf/options-ssl-nginx.conf
openssl dhparam -out certbot/conf/ssl-dhparams.pem 2048
```

### 5.4 Container starten

```bash
docker-compose down
docker-compose up -d
```

## 6. Toolkit testen

Prüfen Sie, ob das Toolkit korrekt läuft:

```bash
curl -X POST https://your-domain.com/v1/toolkit/test -H "X-API-Key: IhrSichererAPISchlüssel"
```

Wenn alles korrekt eingerichtet ist, sollten Sie eine Erfolgsmeldung erhalten.

## 7. Fehlerbehandlung

### 7.1 SSL-Zertifikat-Probleme

Wenn Sie Probleme mit dem SSL-Zertifikat haben:

1. Überprüfen Sie die Nginx-Logs:
   ```bash
   docker-compose logs nginx
   ```

2. Überprüfen Sie die Certbot-Logs:
   ```bash
   docker-compose logs certbot
   ```

3. Häufige Probleme:
   - **Domain zeigt nicht auf den Server**: Stellen Sie sicher, dass Ihre DNS-Einträge korrekt sind
   - **Port 80/443 blockiert**: Stellen Sie sicher, dass die Ports 80 und 443 freigegeben sind
   - **Fehlerhafte Nginx-Konfiguration**: Überprüfen Sie die Nginx-Konfigurationsdatei

Manuelle Zertifikatserstellung:

```bash
# Stoppen Sie die Container
docker-compose down

# SSL-Zertifikat manuell erstellen
certbot certonly --standalone --email your-email@example.com --agree-tos --no-eff-email -d your-domain.com -d www.your-domain.com

# Starten Sie die Container neu
docker-compose up -d
```

### 7.2 Toolkit-Fehler

Bei Problemen mit dem No-Code Architects Toolkit:

1. Überprüfen Sie die Container-Logs:
   ```bash
   docker-compose logs nca-toolkit
   ```

2. Häufige Probleme:
   - **API-Schlüssel fehlt**: Stellen Sie sicher, dass die Umgebungsvariable `API_KEY` gesetzt ist
   - **Speicherpfad-Probleme**: Überprüfen Sie die Berechtigungen für das Verzeichnis `/data`
   - **Container startet nicht**: Überprüfen Sie die Docker-Konfiguration

## 8. Wartung und Updates

### 8.1 SSL-Zertifikate erneuern

Die automatische Erneuerung erfolgt über den Certbot-Container, der alle 12 Stunden prüft. Manuell können Sie die Erneuerung wie folgt auslösen:

```bash
docker-compose run --rm certbot renew
```

### 8.2 Toolkit aktualisieren

```bash
# Aktuelle Version ziehen
docker pull stephengpope/no-code-architects-toolkit:latest

# Container neustarten
docker-compose down
docker-compose up -d
```

### 8.3 Backup

Erstellen Sie regelmäßig Backups des Datenverzeichnisses:

```bash
# Backup erstellen
tar -czvf nca-toolkit-backup-$(date +%Y%m%d).tar.gz /opt/nca-toolkit/data

# Backup auf externen Speicher kopieren
# z.B.: scp nca-toolkit-backup-*.tar.gz user@backup-server:/backups/
```

---

## Nützliche Befehle

```bash
# Container-Status anzeigen
docker-compose ps

# Container-Logs anzeigen
docker-compose logs -f

# In einen Container einsteigen
docker-compose exec nca-toolkit bash

# Container neustarten
docker-compose restart nca-toolkit

# Alle Container stoppen
docker-compose down

# Alle Container starten
docker-compose up -d
```

## Ressourcen

- [No-Code Architects Toolkit GitHub Repository](https://github.com/stephengpope/no-code-architects-toolkit)
- [Docker-Dokumentation](https://docs.docker.com/)
- [Nginx-Dokumentation](https://nginx.org/en/docs/)
- [Certbot-Dokumentation](https://certbot.eff.org/docs/)
