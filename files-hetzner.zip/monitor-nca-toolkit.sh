#!/bin/bash

# No-Code Architects Toolkit Monitoring-Skript
# Dieses Skript überwacht den Status des Toolkits und sendet Benachrichtigungen bei Problemen

# Farbcodes für bessere Lesbarkeit
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Konfiguration
DOMAIN=""                   # Domain-Name
API_KEY=""                  # API-Schlüssel
EMAIL_TO=""                 # E-Mail-Adresse für Benachrichtigungen
CHECK_INTERVAL=300          # Intervall in Sekunden (5 Minuten)
SMTP_SERVER=""              # SMTP-Server für E-Mail-Versand
SMTP_PORT=587               # SMTP-Port
SMTP_USER=""                # SMTP-Benutzername
SMTP_PASSWORD=""            # SMTP-Passwort

# Banner anzeigen
echo -e "${GREEN}"
echo "====================================================="
echo "  No-Code Architects Toolkit - Monitoring-Skript"
echo "====================================================="
echo -e "${NC}"

# Konfigurationsdatei laden, falls vorhanden
CONFIG_FILE="/opt/nca-toolkit/monitor-config.env"
if [ -f "$CONFIG_FILE" ]; then
    source "$CONFIG_FILE"
    echo -e "${GREEN}Konfigurationsdatei wurde geladen.${NC}"
else
    # Konfiguration erfragen, wenn keine Datei vorhanden ist
    echo -e "${YELLOW}Keine Konfigurationsdatei gefunden. Bitte geben Sie die erforderlichen Informationen ein:${NC}"
    read -p "Domain-Name: " DOMAIN
    read -p "API-Schlüssel: " API_KEY
    read -p "E-Mail-Adresse für Benachrichtigungen: " EMAIL_TO
    read -p "SMTP-Server (leer lassen für lokalen Versand): " SMTP_SERVER
    
    if [ ! -z "$SMTP_SERVER" ]; then
        read -p "SMTP-Port [587]: " SMTP_PORT_INPUT
        SMTP_PORT=${SMTP_PORT_INPUT:-587}
        read -p "SMTP-Benutzername: " SMTP_USER
        read -s -p "SMTP-Passwort: " SMTP_PASSWORD
        echo
    fi
    
    read -p "Check-Intervall in Sekunden [300]: " CHECK_INTERVAL_INPUT
    CHECK_INTERVAL=${CHECK_INTERVAL_INPUT:-300}
    
    # Konfigurationsdatei speichern
    mkdir -p /opt/nca-toolkit
    cat > "$CONFIG_FILE" << EOL
DOMAIN="$DOMAIN"
API_KEY="$API_KEY"
EMAIL_TO="$EMAIL_TO"
CHECK_INTERVAL=$CHECK_INTERVAL
SMTP_SERVER="$SMTP_SERVER"
SMTP_PORT=$SMTP_PORT
SMTP_USER="$SMTP_USER"
SMTP_PASSWORD="$SMTP_PASSWORD"
EOL
    chmod 600 "$CONFIG_FILE"
    echo -e "${GREEN}Konfigurationsdatei wurde erstellt.${NC}"
fi

# Funktion zum Senden einer Benachrichtigung
send_notification() {
    local subject="$1"
    local message="$2"
    local timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    
    message="$timestamp\n\n$message"
    
    echo -e "${YELLOW}Benachrichtigung wird gesendet: $subject${NC}"
    
    if [ ! -z "$SMTP_SERVER" ]; then
        # E-Mail über SMTP-Server senden
        printf "Subject: $subject\n\n$message" | curl --ssl-reqd \
            --url "smtp://$SMTP_SERVER:$SMTP_PORT" \
            --user "$SMTP_USER:$SMTP_PASSWORD" \
            --mail-from "$SMTP_USER" \
            --mail-rcpt "$EMAIL_TO" \
            --upload-file -
    else
        # Lokalen Mail-Server verwenden
        echo -e "$message" | mail -s "$subject" "$EMAIL_TO"
    fi
    
    echo -e "${GREEN}Benachrichtigung wurde gesendet.${NC}"
}

# Funktion zum Überprüfen des Container-Status
check_containers() {
    local status="OK"
    local message="Alle Container sind aktiv.\n\n"
    
    # Nginx-Container überprüfen
    if ! docker ps | grep -q "nginx-proxy"; then
        status="FEHLER"
        message+="NGINX-CONTAINER IST NICHT AKTIV!\n"
    else
        message+="Nginx-Container: OK\n"
    fi
    
    # Certbot-Container überprüfen
    if ! docker ps | grep -q "certbot"; then
        status="FEHLER"
        message+="CERTBOT-CONTAINER IST NICHT AKTIV!\n"
    else
        message+="Certbot-Container: OK\n"
    fi
    
    # NCA-Toolkit-Container überprüfen
    if ! docker ps | grep -q "nca-toolkit"; then
        status="FEHLER"
        message+="NCA-TOOLKIT-CONTAINER IST NICHT AKTIV!\n"
    else
        message+="NCA-Toolkit-Container: OK\n"
    fi
    
    if [ "$status" == "FEHLER" ]; then
        send_notification "WARNUNG: NCA-Toolkit Container-Status" "$message"
        return 1
    fi
    
    return 0
}

# Funktion zum Überprüfen des API-Status
check_api() {
    local status="OK"
    local message="API-Test erfolgreich.\n\n"
    
    # API-Test durchführen
    local api_response=$(curl -s -o /dev/null -w "%{http_code}" -X POST "https://$DOMAIN/v1/toolkit/test" -H "X-API-Key: $API_KEY")
    
    if [ "$api_response" != "200" ]; then
        status="FEHLER"
        message+="API-TEST FEHLGESCHLAGEN! HTTP-Statuscode: $api_response\n"
    else
        message+="API-Statuscode: $api_response (OK)\n"
    fi
    
    if [ "$status" == "FEHLER" ]; then
        send_notification "WARNUNG: NCA-Toolkit API-Status" "$message"
        return 1
    fi
    
    return 0
}

# Funktion zum Überprüfen des SSL-Zertifikats
check_ssl() {
    local status="OK"
    local message="SSL-Zertifikat ist gültig.\n\n"
    
    # Zertifikatsablauf überprüfen
    local expiry_date=$(echo | openssl s_client -servername $DOMAIN -connect $DOMAIN:443 2>/dev/null | openssl x509 -noout -enddate | cut -d= -f2)
    local expiry_epoch=$(date -d "$expiry_date" +%s)
    local current_epoch=$(date +%s)
    local seconds_until_expiry=$((expiry_epoch - current_epoch))
    local days_until_expiry=$((seconds_until_expiry / 86400))
    
    message+="Zertifikat läuft ab am: $expiry_date\n"
    message+="Verbleibende Tage: $days_until_expiry\n"
    
    # Warnung, wenn weniger als 14 Tage verbleiben
    if [ "$days_until_expiry" -lt 14 ]; then
        status="WARNUNG"
        message+="ZERTIFIKAT LÄUFT BALD AB! Weniger als 14 Tage verbleibend.\n"
    fi
    
    # Kritischer Fehler, wenn weniger als 3 Tage verbleiben
    if [ "$days_until_expiry" -lt 3 ]; then
        status="FEHLER"
        message+="KRITISCH: ZERTIFIKAT LÄUFT SEHR BALD AB! Weniger als 3 Tage verbleibend.\n"
    fi
    
    if [ "$status" == "WARNUNG" ] || [ "$status" == "FEHLER" ]; then
        send_notification "WARNUNG: NCA-Toolkit SSL-Zertifikat" "$message"
        return 1
    fi
    
    return 0
}

# Funktion zum Überprüfen der Festplattenauslastung
check_disk() {
    local status="OK"
    local message="Festplattenauslastung ist im normalen Bereich.\n\n"
    
    # Festplattennutzung des Datenverzeichnisses überprüfen
    local disk_usage=$(df -h /opt/nca-toolkit/data | awk 'NR==2 {print $5}' | sed 's/%//')
    
    message+="Festplattenauslastung: $disk_usage%\n"
    
    # Warnung ab 80% Nutzung
    if [ "$disk_usage" -ge 80 ]; then
        status="WARNUNG"
        message+="FESTPLATTENAUSLASTUNG IST HOCH! $disk_usage% verwendet.\n"
    fi
    
    # Kritischer Fehler ab 95% Nutzung
    if [ "$disk_usage" -ge 95 ]; then
        status="FEHLER"
        message+="KRITISCH: FESTPLATTE FAST VOLL! $disk_usage% verwendet.\n"
    fi
    
    if [ "$status" == "WARNUNG" ] || [ "$status" == "FEHLER" ]; then
        send_notification "WARNUNG: NCA-Toolkit Festplattenauslastung" "$message"
        return 1
    fi
    
    return 0
}

# Monitoring-Hauptschleife
echo -e "${GREEN}Monitoring wird gestartet...${NC}"
echo "Domain: $DOMAIN"
echo "Check-Intervall: $CHECK_INTERVAL Sekunden"
echo "Benachrichtigungen an: $EMAIL_TO"
echo

# Daemon-Modus, wenn als Systemd-Service ausgeführt
if [ "$1" == "--daemon" ]; then
    while true; do
        check_containers
        check_api
        check_ssl
        check_disk
        sleep $CHECK_INTERVAL
    done
else
    # Interaktiver Modus
    echo -e "${YELLOW}Monitoring-Funktionen:${NC}"
    echo "1. Container-Status überprüfen"
    echo "2. API-Status überprüfen"
    echo "3. SSL-Zertifikat überprüfen"
    echo "4. Festplattenauslastung überprüfen"
    echo "5. Alle Prüfungen durchführen"
    echo "6. Kontinuierliches Monitoring starten"
    echo "7. Monitoring als Systemd-Service einrichten"
    echo "8. Beenden"
    
    while true; do
        read -p "Wählen Sie eine Option (1-8): " OPTION
        
        case $OPTION in
            1)
                check_containers
                ;;
            2)
                check_api
                ;;
            3)
                check_ssl
                ;;
            4)
                check_disk
                ;;
            5)
                check_containers
                check_api
                check_ssl
                check_disk
                ;;
            6)
                echo -e "${GREEN}Kontinuierliches Monitoring wird gestartet. Drücken Sie STRG+C zum Beenden.${NC}"
                while true; do
                    check_containers
                    check_api
                    check_ssl
                    check_disk
                    sleep $CHECK_INTERVAL
                done
                ;;
            7)
                # Systemd-Service erstellen
                echo -e "${GREEN}Systemd-Service wird eingerichtet...${NC}"
                SERVICE_FILE="/etc/systemd/system/nca-toolkit-monitor.service"
                
                cat > $SERVICE_FILE << EOL
[Unit]
Description=No-Code Architects Toolkit Monitoring Service
After=docker.service

[Service]
ExecStart=$(readlink -f $0) --daemon
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOL
                
                systemctl daemon-reload
                systemctl enable nca-toolkit-monitor.service
                systemctl start nca-toolkit-monitor.service
                
                echo -e "${GREEN}Systemd-Service wurde eingerichtet und gestartet.${NC}"
                echo "Status überprüfen mit: systemctl status nca-toolkit-monitor.service"
                ;;
            8)
                echo -e "${GREEN}Monitoring wird beendet.${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}Ungültige Option. Bitte wählen Sie eine Option von 1 bis 8.${NC}"
                ;;
        esac
    done
fi
