#!/bin/bash

# No-Code Architects Toolkit auf Hetzner Deployment-Skript
# Dieses Skript automatisiert die Bereitstellung des NCA-Toolkits auf einem Hetzner-Server

set -e

# Farbcodes für bessere Lesbarkeit
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Banner anzeigen
echo -e "${GREEN}"
echo "====================================================="
echo "  No-Code Architects Toolkit - Hetzner Deployment"
echo "====================================================="
echo -e "${NC}"

# Überprüfen, ob das Skript als Root ausgeführt wird
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Bitte führen Sie das Skript als Root aus.${NC}"
  exit 1
fi

# Domain-Name erfragen
read -p "Geben Sie Ihren Domain-Namen ein (z.B. nca-toolkit.example.com): " DOMAIN_NAME
read -p "Geben Sie Ihre E-Mail-Adresse für Let's Encrypt ein: " EMAIL_ADDRESS

# API-Schlüssel generieren, falls keiner angegeben wird
read -p "Geben Sie einen API-Schlüssel ein (leer lassen für automatische Generierung): " API_KEY
if [ -z "$API_KEY" ]; then
  API_KEY=$(openssl rand -hex 16)
  echo -e "${GREEN}API-Schlüssel generiert: ${YELLOW}$API_KEY${NC}"
  echo "Bitte notieren Sie sich diesen Schlüssel für späteren Zugriff!"
else
  echo -e "${GREEN}Verwendeter API-Schlüssel: ${YELLOW}$API_KEY${NC}"
fi

echo -e "\n${GREEN}System wird aktualisiert...${NC}"
apt update && apt upgrade -y

echo -e "\n${GREEN}Benötigte Pakete werden installiert...${NC}"
apt install -y apt-transport-https ca-certificates curl software-properties-common git ufw

echo -e "\n${GREEN}Firewall wird eingerichtet...${NC}"
ufw allow ssh
ufw allow http
ufw allow https
ufw --force enable

echo -e "\n${GREEN}Docker wird installiert...${NC}"
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
echo "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
apt update
apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
systemctl enable docker
systemctl start docker

echo -e "\n${GREEN}Projektverzeichnis wird erstellt...${NC}"
mkdir -p /opt/nca-toolkit
cd /opt/nca-toolkit

echo -e "\n${GREEN}Repository wird geklont...${NC}"
git clone https://github.com/stephengpope/no-code-architects-toolkit.git .

echo -e "\n${GREEN}Konfiguration wird erstellt...${NC}"
mkdir -p data nginx certbot/conf certbot/www

echo -e "\n${GREEN}Umgebungsvariablen werden konfiguriert...${NC}"
cat > .env << EOL
# API-Konfiguration
API_KEY=${API_KEY}

# Speicherkonfiguration
LOCAL_STORAGE_PATH=/data

# Performance-Einstellungen
MAX_QUEUE_LENGTH=10
GUNICORN_WORKERS=4
GUNICORN_TIMEOUT=300
EOL

echo -e "\n${GREEN}Docker Compose Datei wird erstellt...${NC}"
cat > docker-compose.yml << EOL
version: '3'

services:
  nca-toolkit:
    image: stephengpope/no-code-architects-toolkit:latest
    container_name: nca-toolkit
    ports:
      - "127.0.0.1:8080:8080"
    volumes:
      - ./data:/data
    env_file:
      - .env
    restart: unless-stopped

  nginx:
    image: nginx:latest
    container_name: nginx-proxy
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx:/etc/nginx/conf.d
      - ./certbot/conf:/etc/letsencrypt
      - ./certbot/www:/var/www/certbot
    depends_on:
      - nca-toolkit
    restart: unless-stopped

  certbot:
    image: certbot/certbot:latest
    container_name: certbot
    volumes:
      - ./certbot/conf:/etc/letsencrypt
      - ./certbot/www:/var/www/certbot
    entrypoint: "/bin/sh -c 'trap exit TERM; while :; do certbot renew; sleep 12h & wait \$\${!}; done;'"
EOL

echo -e "\n${GREEN}Nginx-Konfiguration wird erstellt...${NC}"
cat > nginx/app.conf << EOL
server {
    listen 80;
    server_name ${DOMAIN_NAME} www.${DOMAIN_NAME};
    
    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }
    
    location / {
        return 301 https://\$host\$request_uri;
    }
}

server {
    listen 443 ssl;
    server_name ${DOMAIN_NAME} www.${DOMAIN_NAME};
    
    ssl_certificate /etc/letsencrypt/live/${DOMAIN_NAME}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${DOMAIN_NAME}/privkey.pem;
    
    include /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;
    
    location / {
        proxy_pass http://nca-toolkit:8080;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }

    # Größere Uploads erlauben
    client_max_body_size 500M;
}
EOL

echo -e "\n${GREEN}SSL-Konfiguration wird erstellt...${NC}"
mkdir -p certbot/conf
curl -s https://raw.githubusercontent.com/certbot/certbot/master/certbot-nginx/certbot_nginx/_internal/tls_configs/options-ssl-nginx.conf > certbot/conf/options-ssl-nginx.conf
openssl dhparam -out certbot/conf/ssl-dhparams.pem 2048

echo -e "\n${GREEN}Nginx-Container wird gestartet...${NC}"
docker compose up -d nginx

echo -e "\n${GREEN}SSL-Zertifikat wird beantragt...${NC}"
docker compose run --rm certbot certonly --webroot --webroot-path=/var/www/certbot --email ${EMAIL_ADDRESS} --agree-tos --no-eff-email -d ${DOMAIN_NAME} -d www.${DOMAIN_NAME}

echo -e "\n${GREEN}Alle Container werden gestartet...${NC}"
docker compose down
docker compose up -d

echo -e "\n${GREEN}================================================================${NC}"
echo -e "${GREEN}Bereitstellung abgeschlossen!${NC}"
echo -e "${GREEN}================================================================${NC}"
echo -e "Domain: https://${DOMAIN_NAME}"
echo -e "API-Schlüssel: ${YELLOW}${API_KEY}${NC}"
echo -e "\nTesten Sie das Toolkit mit:"
echo -e "curl -X POST https://${DOMAIN_NAME}/v1/toolkit/test -H \"X-API-Key: ${API_KEY}\""
echo -e "\n${GREEN}================================================================${NC}"

# Kurze Anleitung anzeigen, wie das Toolkit verwendet werden kann
echo -e "${GREEN}Nützliche Befehle:${NC}"
echo -e "  - Container-Status anzeigen: ${YELLOW}docker compose ps${NC}"
echo -e "  - Logs anzeigen: ${YELLOW}docker compose logs -f${NC}"
echo -e "  - Alle Container neustarten: ${YELLOW}docker compose restart${NC}"
echo -e "  - Toolkit aktualisieren: ${YELLOW}docker compose down && docker pull stephengpope/no-code-architects-toolkit:latest && docker compose up -d${NC}"
